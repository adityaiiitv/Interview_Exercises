package jackson;

public class ToDisplay
{
    private String track;
    private String image;
    private String collection;

    public String getTrack()
    {
        return track;
    }

    public String getImage()
    {
        return image;
    }

    public String getCollection()
    {
        return collection;
    }

    public ToDisplay(String track, String image, String collection)
    {
        this.track = track;
        this.image = image;
        this.collection = collection;
    }
}
