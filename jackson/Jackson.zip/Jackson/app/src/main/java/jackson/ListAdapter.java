package jackson;
import aditya.jackson.R;
import android.app.Activity;
import android.content.Context;
import com.squareup.picasso.Picasso;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListAdapter extends ArrayAdapter<ToDisplay>
{
    private Context con;
    @Override
    public View getView(int index, View v, ViewGroup parent)
    {
        if (v == null)
        {
            LayoutInflater LI = (LayoutInflater) getContext()
                    .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            v = LI.inflate(R.layout.list_adapter, null, true);
        }
        ToDisplay toDisplay = getItem(index);
        TextView track = v.findViewById(R.id.trackName);
        ImageView image = v.findViewById(R.id.imageViewProduct);
        TextView collection = v.findViewById(R.id.collectionName);
        track.setText(toDisplay.getTrack());
        Picasso.with(con).load(toDisplay.getImage()).into(image);
        collection.setText(toDisplay.getCollection());
        return v;
    }

    public ListAdapter(Context con, int res, ArrayList<ToDisplay> displayList)
    {
        super(con, res, displayList);
        this.con = con;
    }
}