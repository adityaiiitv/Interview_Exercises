package jackson;
import aditya.jackson.R;
import android.widget.TextView;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Details extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        TextView wrapperType = findViewById(R.id.wrapperType);
        TextView kind = findViewById(R.id.kind);
        TextView artistId = findViewById(R.id.artistId);
        TextView collectionId = findViewById(R.id.collectionId);
        TextView trackId = findViewById(R.id.trackId);
        TextView artistName = findViewById(R.id.artistName);
        TextView collectionName = findViewById(R.id.collectionName);
        TextView trackName = findViewById(R.id.trackName);
        TextView collectionCensoredName = findViewById(R.id.collectionCensoredName);
        TextView trackCensoredName = findViewById(R.id.trackCensoredName);
        TextView artistViewUrl = findViewById(R.id.artistViewUrl);
        TextView collectionViewUrl = findViewById(R.id.collectionViewUrl);
        TextView trackViewUrl = findViewById(R.id.trackViewUrl);
        TextView previewUrl = findViewById(R.id.previewUrl);
        TextView artworkUrl30 = findViewById(R.id.artworkUrl30);
        TextView artworkUrl60 = findViewById(R.id.artworkUrl60);
        TextView artworkUrl100 = findViewById(R.id.artworkUrl100);
        TextView collectionPrice = findViewById(R.id.collectionPrice);
        TextView trackPrice = findViewById(R.id.trackPrice);
        TextView releaseDate = findViewById(R.id.releaseDate);
        TextView collectionExplicitness = findViewById(R.id.collectionExplicitness);
        TextView trackExplicitness = findViewById(R.id.trackExplicitness);
        TextView discCount = findViewById(R.id.discCount);
        TextView discNumber = findViewById(R.id.discNumber);
        TextView trackCount = findViewById(R.id.trackCount);
        TextView trackNumber = findViewById(R.id.trackNumber);
        TextView trackTimeMillis = findViewById(R.id.trackTimeMillis);
        TextView country = findViewById(R.id.country);
        TextView currency = findViewById(R.id.currency);
        TextView primaryGenreName = findViewById(R.id.primaryGenreName);
        TextView isStreamable = findViewById(R.id.isStreamable);
        wrapperType.setText("Wrapper Type: "+getIntent().getExtras().getString("wrapperType"));
        kind.setText("Kind: "+getIntent().getExtras().getString("kind"));
        artistId.setText("Artist Id: "+getIntent().getExtras().getString("artistId"));
        collectionId.setText("Collection Id: "+getIntent().getExtras().getString("collectionId"));
        trackId.setText("Track Id: "+getIntent().getExtras().getString("trackId"));
        artistName.setText("Artist Name: "+getIntent().getExtras().getString("artistName"));
        collectionName.setText("Collection Name: "+getIntent().getExtras().getString("collectionName"));
        trackName.setText("Track Name: "+getIntent().getExtras().getString("trackName"));
        collectionCensoredName.setText("Collection Censored Name: "+getIntent().getExtras().getString("collectionCensoredName"));
        trackCensoredName.setText("Track Censored Name: "+getIntent().getExtras().getString("trackCensoredName"));
        artistViewUrl.setText("Artist View URL: "+getIntent().getExtras().getString("artistViewUrl"));
        collectionViewUrl.setText("Collection View URL: "+getIntent().getExtras().getString("collectionViewUrl"));
        trackViewUrl.setText("Track View URL: "+getIntent().getExtras().getString("trackViewUrl"));
        previewUrl.setText("Preview URL: "+getIntent().getExtras().getString("previewUrl"));
        artworkUrl30.setText("Artwork URL 30: "+getIntent().getExtras().getString("artworkUrl30"));
        artworkUrl60.setText("Artwork URL 60: "+getIntent().getExtras().getString("artworkUrl60"));
        artworkUrl100.setText("Artwork URL 100: "+getIntent().getExtras().getString("artworkUrl100"));
        collectionPrice.setText("Collection Price: "+getIntent().getExtras().getString("collectionPrice"));
        trackPrice.setText("Track Price: "+getIntent().getExtras().getString("trackPrice"));
        releaseDate.setText("Release Date: "+getIntent().getExtras().getString("releaseDate"));
        collectionExplicitness.setText("Collection Explicitness: "+getIntent().getExtras().getString("collectionExplicitness"));
        trackExplicitness.setText("Track Explicitness: "+getIntent().getExtras().getString("trackExplicitness"));
        discCount.setText("Disc Count: "+getIntent().getExtras().getString("discCount"));
        discNumber.setText("Disc Number: "+getIntent().getExtras().getString("discNumber"));
        trackCount.setText("Track Count: "+getIntent().getExtras().getString("trackCount"));
        trackNumber.setText("Track Number: "+getIntent().getExtras().getString("trackNumber"));
        trackTimeMillis.setText("Track Time Milliseconds: "+getIntent().getExtras().getString("trackTimeMillis"));
        country.setText("Country: "+getIntent().getExtras().getString("country"));
        currency.setText("Currency: "+getIntent().getExtras().getString("currency"));
        primaryGenreName.setText("Primary Genre Name: "+getIntent().getExtras().getString("primaryGenreName"));
        isStreamable.setText("Is Streamable: "+getIntent().getExtras().getString("isStreamable"));
    }
}