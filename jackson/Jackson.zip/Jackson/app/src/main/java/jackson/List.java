package jackson;
import aditya.jackson.R;
import android.os.AsyncTask;
import android.os.Bundle;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.widget.AdapterView;
import android.widget.ListView;
import android.view.View;
import java.util.ArrayList;
import java.net.URL;
import java.net.URLConnection;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

public class List extends AppCompatActivity
{
    private String wrapperType;
    private String kind;
    private String artistId;
    private String collectionId;
    private String trackID;
    private String artistName;
    private String collectionName;
    private String trackName;
    private String collectionCensoredName;
    private String trackCensoredName;
    private String artistViewUrl;
    private String collectionViewUrl;
    private String trackViewUrl;
    private String previewUrl;
    private String artworkUrl30;
    private String artworkUrl60;
    private String artworkUrl100;
    private String collectionPrice;
    private String trackPrice;
    private String releaseDate;
    private String collectionExplicitness;
    private String trackExplicitness;
    private String discCount;
    private String discNumber;
    private String trackCount;
    private String trackNumber;
    private String trackTimeMillis;
    private String country;
    private String currency;
    private String primaryGenreName;
    private String isStreamable;
    private JSONObject detailJSON;
    private JSONArray jArray;
    public String jacksonURL = "https://itunes.apple.com/search?term=Michael+Jackson";
    private ArrayList<ToDisplay> songList;
    private ListView lview;
    JSONObject finalJSON;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        lview = findViewById(R.id.list);
        songList = new ArrayList<>();
        lview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
               getDataForThisPosition(position);
            }
        });
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                new ExtractJSON().execute(jacksonURL);
            }
        });
    }

    private void getDataForThisPosition(Integer index)
    {
        try
        {
            jArray =  finalJSON.getJSONArray("results");
            detailJSON = jArray.getJSONObject(index);
            wrapperType =  detailJSON.getString("wrapperType");
            kind =  detailJSON.getString("kind");
            artistId = detailJSON.getString("artistId");
            collectionId = detailJSON.getString("collectionId");
            trackID = detailJSON.getString("trackId");
            artistName = detailJSON.getString("artistName");
            collectionName = detailJSON.getString("collectionName");
            trackName = detailJSON.getString("trackName");
            collectionCensoredName = detailJSON.getString("collectionCensoredName");
            trackCensoredName = detailJSON.getString("trackCensoredName");
            artistViewUrl = detailJSON.getString("artistViewUrl");
            collectionViewUrl = detailJSON.getString("collectionViewUrl");
            trackViewUrl = detailJSON.getString("trackViewUrl");
            previewUrl = detailJSON.getString("previewUrl");
            artworkUrl30 = detailJSON.getString("artworkUrl30");
            artworkUrl60 = detailJSON.getString("artworkUrl60");
            artworkUrl100 = detailJSON.getString("artworkUrl100");
            collectionPrice = detailJSON.getString("collectionPrice");
            trackPrice = detailJSON.getString("trackPrice");
            releaseDate = detailJSON.getString("releaseDate");
            collectionExplicitness = detailJSON.getString("collectionExplicitness");
            trackExplicitness = detailJSON.getString("trackExplicitness");
            discCount = detailJSON.getString("discCount");
            discNumber = detailJSON.getString("discNumber");
            trackCount = detailJSON.getString("trackCount");
            trackNumber = detailJSON.getString("trackNumber");
            trackTimeMillis = detailJSON.getString("trackTimeMillis");
            country = detailJSON.getString("country");
            currency = detailJSON.getString("currency");
            primaryGenreName = detailJSON.getString("primaryGenreName");
            isStreamable = detailJSON.getString("isStreamable");
            Intent intent = new Intent(List.this, Details.class);
            intent.putExtra("wrapperType",wrapperType);
            intent.putExtra("kind",kind);
            intent.putExtra("artistId",artistId);
            intent.putExtra("collectionId",collectionId);
            intent.putExtra("trackId",trackID);
            intent.putExtra("artistName",artistName);
            intent.putExtra("collectionName",collectionName);
            intent.putExtra("trackName",trackName);
            intent.putExtra("collectionCensoredName",collectionCensoredName);
            intent.putExtra("trackCensoredName",trackCensoredName);
            intent.putExtra("artistViewUrl",artistViewUrl);
            intent.putExtra("collectionViewUrl",collectionViewUrl);
            intent.putExtra("trackViewUrl",trackViewUrl);
            intent.putExtra("previewUrl",previewUrl);
            intent.putExtra("artworkUrl30",artworkUrl30);
            intent.putExtra("artworkUrl60",artworkUrl60);
            intent.putExtra("artworkUrl100",artworkUrl100);
            intent.putExtra("CollectionPrice",collectionPrice);
            intent.putExtra("trackPrice",trackPrice);
            intent.putExtra("releaseDate",releaseDate);
            intent.putExtra("collectionExplicitness",collectionExplicitness);
            intent.putExtra("trackExplicitness",trackExplicitness);
            intent.putExtra("discCount",discCount);
            intent.putExtra("discNumber",discNumber);
            intent.putExtra("trackCount",trackCount);
            intent.putExtra("trackNumber",trackNumber);
            intent.putExtra("trackTimeMillis",trackTimeMillis);
            intent.putExtra("country",country);
            intent.putExtra("currency",currency);
            intent.putExtra("primaryGenreName",primaryGenreName);
            intent.putExtra("isStreamable",isStreamable);
            startActivity(intent);
        }
        catch (JSONException ex)
        {
            ex.printStackTrace();
        }
    }

    class ExtractJSON extends AsyncTask<String, Integer, String>
    {
        @Override
        protected String doInBackground(String... params)
        {
            return openURL(params[0]);
        }

        @Override
        protected void onPostExecute(String con)
        {
            try
            {
                finalJSON = new JSONObject(con);
                jArray =  finalJSON.getJSONArray("results");
                int i=0;
                while(i<jArray.length())
                {
                    detailJSON = jArray.optJSONObject(i);
                    songList.add(new ToDisplay(
                            detailJSON.getString("trackName"),
                            detailJSON.getString("artworkUrl100"),
                            detailJSON.getString("collectionName")
                    ));
                    i++;
                }
            }
            catch (JSONException ex)
            {
                ex.printStackTrace();
            }
            ListAdapter adapter = new ListAdapter(
                    getApplicationContext(), R.layout.list_adapter, songList
            );
            lview.setAdapter(adapter);
        }
    }

    private static String openURL(String theUrl)
    {
        StringBuilder content = new StringBuilder();
        try
        {
            URL url = new URL(theUrl);
            URLConnection connection = url.openConnection();
            BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = br.readLine()) != null)
            {
                content.append(line + "\n");
            }
            br.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return content.toString();
    }
}