#include <iostream>
#include "opencv2/highgui/highgui.hpp"
using namespace cv;
using namespace std;

int main()
{
    VideoCapture cap("drop.avi");
    // cap is the object of class video capture that tries to capture Bumpy.mp4
    if ( !cap.isOpened() )  // isOpened() returns true if capturing has been initialized.
    {
        cout << "Cannot open the video file. \n";
        return -1;
    }
    int frame_width = cap.get(CV_CAP_PROP_FRAME_WIDTH);
    int frame_height = cap.get(CV_CAP_PROP_FRAME_HEIGHT);
    double fps = cap.get(CV_CAP_PROP_FPS); //get the frames per seconds of the video
    VideoWriter video("output.mp4", CV_FOURCC('M','P','4','V'), 10,Size(frame_width,frame_height));
    namedWindow("A_good_name",CV_WINDOW_AUTOSIZE); //create a window called "MyVideo"
    int iter =0;
    int total = fps * 5;
    while(iter<total)
    {
        iter++;
        Mat frame;
        // Mat object is a basic image container. frame is an object of Mat.
        if (!cap.read(frame)) // if not success, break loop
        // read() decodes and captures the next frame.
        {
            cout<<"\n Cannot read the video file. \n";
            break;
        }

        video.write(frame);
        imshow("A_good_name", frame);
        // first argument: name of the window.
        // second argument: image to be shown(Mat object).

        if(waitKey(30) == 27) // Wait for 'esc' key press to exit
        {
            break;
        }
    }
    cap.release();
    video.release();
    destroyAllWindows();
    return 0;
}
